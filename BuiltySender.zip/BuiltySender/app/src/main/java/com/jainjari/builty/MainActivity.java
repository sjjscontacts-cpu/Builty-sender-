package com.jainjari.builty;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanner;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 101;
    private static final int REQ_SCAN = 102;
    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private TextRecognizer recognizer;
    private final ExecutorService bg = Executors.newSingleThreadExecutor();

    private String scanId;
    /** Photo waiting to be sent after the receiver's chat was opened for the first time. */
    private Uri pendingPhoto;
    private String pendingJid;
    private String pendingPkg;
    private boolean leftForChat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                cameraUri = null;
                Intent intent;
                if (params.isCaptureEnabled()) {
                    try {
                        File dir = new File(getCacheDir(), "cam");
                        dir.mkdirs();
                        File f = new File(dir, "cap_" + System.currentTimeMillis() + ".jpg");
                        cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                        intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {
                        cameraUri = null;
                        intent = params.createIntent();
                    }
                } else {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No camera or gallery app found", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl(START_URL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (pendingPhoto != null) leftForChat = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Back from the receiver's chat: now send the photo straight into that chat.
        if (pendingPhoto != null && leftForChat) {
            final Uri photo = pendingPhoto;
            final String jid = pendingJid, pkg = pendingPkg;
            pendingPhoto = null;
            leftForChat = false;
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    startActivity(photoIntent(pkg, photo, jid, null));
                    event("photoSent");
                } catch (Exception e) {
                    Toast.makeText(this, "Could not open WhatsApp for the photo", Toast.LENGTH_LONG).show();
                }
            }, 350);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SCAN) {
            final String id = scanId;
            scanId = null;
            if (id == null) return;
            if (resultCode != RESULT_OK || data == null) { done(id, false, "cancelled"); return; }
            GmsDocumentScanningResult result = GmsDocumentScanningResult.fromActivityResultIntent(data);
            if (result == null || result.getPages() == null || result.getPages().isEmpty()) { done(id, false, "cancelled"); return; }
            final Uri page = result.getPages().get(0).getImageUri();
            bg.execute(() -> {
                try { done(id, true, jpegBase64(page, 2200)); }
                catch (Exception e) { done(id, false, String.valueOf(e.getMessage())); }
            });
            return;
        }
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] res = null;
        if (resultCode == RESULT_OK) {
            if (cameraUri != null) res = new Uri[]{cameraUri};
            else if (data != null && data.getData() != null) res = new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(res);
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /* ---------- helpers ---------- */

    private void done(final String id, final boolean ok, final String text) {
        runOnUiThread(() -> web.evaluateJavascript(
                "window.__nativeDone(" + JSONObject.quote(id) + "," + ok + "," + JSONObject.quote(text == null ? "" : text) + ")", null));
    }

    private void event(final String name) {
        runOnUiThread(() -> web.evaluateJavascript("window.__nativeEvent && window.__nativeEvent(" + JSONObject.quote(name) + ")", null));
    }

    private boolean installed(String pkg) {
        try { getPackageManager().getPackageInfo(pkg, 0); return true; }
        catch (PackageManager.NameNotFoundException e) { return false; }
    }

    private String whatsappPackage() {
        if (installed("com.whatsapp")) return "com.whatsapp";
        if (installed("com.whatsapp.w4b")) return "com.whatsapp.w4b";
        return null;
    }

    private Intent photoIntent(String pkg, Uri photo, String jid, String caption) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/jpeg");
        i.setPackage(pkg);
        i.putExtra(Intent.EXTRA_STREAM, photo);
        if (caption != null) i.putExtra(Intent.EXTRA_TEXT, caption);
        i.putExtra("jid", jid);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }

    /** Read an image, scale it so the long side is at most maxSide, return JPEG as base64. */
    private String jpegBase64(Uri uri, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxSide) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(uri)) { bmp = BitmapFactory.decodeStream(in, null, o2); }
        if (bmp == null) throw new Exception("could not read scan");
        int longSide = Math.max(bmp.getWidth(), bmp.getHeight());
        if (longSide > maxSide) {
            float k = maxSide / (float) longSide;
            bmp = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * k), Math.round(bmp.getHeight() * k), true);
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, bos);
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    /** Every text line with its position, so the page can tell Consignor from Consignee columns. */
    private String layoutJson(Text t, int w, int h) {
        try {
            JSONArray arr = new JSONArray();
            for (Text.TextBlock b : t.getTextBlocks()) {
                for (Text.Line l : b.getLines()) {
                    Rect r = l.getBoundingBox();
                    if (r == null) continue;
                    JSONObject j = new JSONObject();
                    j.put("t", l.getText());
                    j.put("x", r.left);
                    j.put("y", r.top);
                    j.put("w", r.width());
                    j.put("h", r.height());
                    arr.put(j);
                }
            }
            JSONObject o = new JSONObject();
            o.put("w", w);
            o.put("h", h);
            o.put("lines", arr);
            o.put("text", t.getText());
            return o.toString();
        } catch (Exception e) {
            return t.getText();
        }
    }

    /* ---------- called from the page ---------- */

    private class Bridge {

        /** Google document scanner: finds the edges, crops, straightens and cleans the builty. */
        @JavascriptInterface
        public void scan(final String id) {
            runOnUiThread(() -> {
                try {
                    GmsDocumentScannerOptions options = new GmsDocumentScannerOptions.Builder()
                            .setGalleryImportAllowed(true)
                            .setPageLimit(1)
                            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                            .build();
                    GmsDocumentScanner scanner = GmsDocumentScanning.getClient(options);
                    scanner.getStartScanIntent(MainActivity.this)
                            .addOnSuccessListener(sender -> {
                                try {
                                    scanId = id;
                                    startIntentSenderForResult(sender, REQ_SCAN, null, 0, 0, 0);
                                } catch (IntentSender.SendIntentException e) {
                                    scanId = null;
                                    done(id, false, "scanner unavailable");
                                }
                            })
                            .addOnFailureListener(e -> done(id, false, "scanner unavailable: " + e.getMessage()));
                } catch (Exception e) {
                    done(id, false, "scanner unavailable");
                }
            });
        }

        /** Read the text on the photo (offline), with line positions. */
        @JavascriptInterface
        public void ocr(final String id, final String b64) {
            bg.execute(() -> {
                try {
                    byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                    final Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bmp == null) { done(id, false, "bad image"); return; }
                    recognizer.process(InputImage.fromBitmap(bmp, 0))
                            .addOnSuccessListener(t -> done(id, true, layoutJson(t, bmp.getWidth(), bmp.getHeight())))
                            .addOnFailureListener(e -> done(id, false, e.getMessage()));
                } catch (Exception e) {
                    done(id, false, e.getMessage());
                }
            });
        }

        /**
         * mode "direct": open the receiver's chat with photo + message attached (number chatted before).
         * mode "twostep": open the receiver's chat by number with the message (always works, even for
         * new numbers); when the user comes back, the photo opens straight in that same chat.
         */
        @JavascriptInterface
        public void sendWhatsApp(final String id, final String b64, final String phone, final String text, final String mode) {
            runOnUiThread(() -> {
                try {
                    String pkg = whatsappPackage();
                    if (pkg == null) { done(id, false, "WhatsApp not installed"); return; }
                    String digits = phone.replaceAll("\\D", "");
                    String jid = digits + "@s.whatsapp.net";

                    File dir = new File(getCacheDir(), "share");
                    dir.mkdirs();
                    File[] old = dir.listFiles();
                    if (old != null) for (File o : old) if (o.lastModified() < System.currentTimeMillis() - 3600_000L) o.delete();
                    File f = new File(dir, "builty_" + System.currentTimeMillis() + ".jpg");
                    try (FileOutputStream out = new FileOutputStream(f)) { out.write(Base64.decode(b64, Base64.DEFAULT)); }
                    Uri photo = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);

                    if ("direct".equals(mode)) {
                        startActivity(photoIntent(pkg, photo, jid, text));
                    } else {
                        String q = "?phone=" + digits + "&text=" + URLEncoder.encode(text, "UTF-8");
                        Intent chat = new Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send" + q));
                        chat.setPackage(pkg);
                        pendingPhoto = photo;
                        pendingJid = jid;
                        pendingPkg = pkg;
                        leftForChat = false;
                        try {
                            startActivity(chat);
                        } catch (android.content.ActivityNotFoundException nf) {
                            Intent web2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send" + q));
                            web2.setPackage(pkg);
                            startActivity(web2);
                        }
                    }
                    done(id, true, "");
                } catch (Exception e) {
                    pendingPhoto = null;
                    done(id, false, String.valueOf(e.getMessage()));
                }
            });
        }

        /** Save the photo to Gallery > Pictures > Builty. */
        @JavascriptInterface
        public void savePhoto(final String id, final String b64, final String name) {
            bg.execute(() -> {
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                    v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Builty");
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) { done(id, false, "no uri"); return; }
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        out.write(Base64.decode(b64, Base64.DEFAULT));
                    }
                    done(id, true, "");
                } catch (Exception e) {
                    done(id, false, e.getMessage());
                }
            });
        }
    }
}
