package com.jainjari.builty;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 101;
    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private TextRecognizer recognizer;
    private final ExecutorService bg = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                cameraUri = null;
                Intent intent;
                if (params.isCaptureEnabled()) {
                    try {
                        File dir = new File(getCacheDir(), "cam");
                        dir.mkdirs();
                        File f = new File(dir, "cap_" + System.currentTimeMillis() + ".jpg");
                        cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                        intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {
                        cameraUri = null;
                        intent = params.createIntent();
                    }
                } else {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No camera or gallery app found", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl(START_URL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (cameraUri != null) result = new Uri[]{cameraUri};
            else if (data != null && data.getData() != null) result = new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private void done(final String id, final boolean ok, final String text) {
        runOnUiThread(() -> web.evaluateJavascript(
                "window.__nativeDone(" + JSONObject.quote(id) + "," + ok + "," + JSONObject.quote(text == null ? "" : text) + ")",
                null));
    }

    /** Every text line with its position, so the page can tell Consignor from Consignee columns. */
    private String layoutJson(Text t, int w, int h) {
        try {
            JSONArray arr = new JSONArray();
            for (Text.TextBlock b : t.getTextBlocks()) {
                for (Text.Line l : b.getLines()) {
                    Rect r = l.getBoundingBox();
                    if (r == null) continue;
                    JSONObject j = new JSONObject();
                    j.put("t", l.getText());
                    j.put("x", r.left);
                    j.put("y", r.top);
                    j.put("w", r.width());
                    j.put("h", r.height());
                    arr.put(j);
                }
            }
            JSONObject o = new JSONObject();
            o.put("w", w);
            o.put("h", h);
            o.put("lines", arr);
            o.put("text", t.getText());
            return o.toString();
        } catch (Exception e) {
            return t.getText();
        }
    }

    private boolean installed(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private class Bridge {

        /** Read text from the builty photo on the phone (ML Kit, works offline). */
        @JavascriptInterface
        public void ocr(final String id, final String b64) {
            bg.execute(() -> {
                try {
                    byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bmp == null) { done(id, false, "bad image"); return; }
                    InputImage img = InputImage.fromBitmap(bmp, 0);
                    recognizer.process(img)
                            .addOnSuccessListener(t -> done(id, true, layoutJson(t, bmp.getWidth(), bmp.getHeight())))
                            .addOnFailureListener(e -> done(id, false, e.getMessage()));
                } catch (Exception e) {
                    done(id, false, e.getMessage());
                }
            });
        }

        /** Open the receiver's WhatsApp chat directly with the photo and message attached. */
        @JavascriptInterface
        public void shareWhatsApp(final String id, final String b64, final String phone, final String text) {
            runOnUiThread(() -> {
                try {
                    String pkg = installed("com.whatsapp") ? "com.whatsapp"
                            : installed("com.whatsapp.w4b") ? "com.whatsapp.w4b" : null;
                    if (pkg == null) { done(id, false, "WhatsApp not installed"); return; }

                    File dir = new File(getCacheDir(), "share");
                    dir.mkdirs();
                    File[] old = dir.listFiles();
                    if (old != null) for (File o : old) o.delete();
                    File f = new File(dir, "builty_" + System.currentTimeMillis() + ".jpg");
                    try (FileOutputStream out = new FileOutputStream(f)) {
                        out.write(Base64.decode(b64, Base64.DEFAULT));
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);

                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("image/jpeg");
                    i.setPackage(pkg);
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    i.putExtra("jid", phone.replaceAll("\\D", "") + "@s.whatsapp.net");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(i);
                    done(id, true, "");
                } catch (Exception e) {
                    done(id, false, e.getMessage());
                }
            });
        }

        /** Save the photo to Gallery > Pictures > Builty. */
        @JavascriptInterface
        public void savePhoto(final String id, final String b64, final String name) {
            bg.execute(() -> {
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                    v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Builty");
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) { done(id, false, "no uri"); return; }
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        out.write(Base64.decode(b64, Base64.DEFAULT));
                    }
                    done(id, true, "");
                } catch (Exception e) {
                    done(id, false, e.getMessage());
                }
            });
        }
    }
}
