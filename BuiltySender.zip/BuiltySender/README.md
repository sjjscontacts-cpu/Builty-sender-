# Builty Sender (Android app) — Shree Jain Jari Store

Scan a builty → details are read on the phone → one tap opens the receiver's
WhatsApp chat with the builty photo and message already attached → tap Send.
Every builty is kept in the Saved tab.

## Build the APK for free with GitHub (needs a computer browser, ~10 min)

1. Make a free account at github.com (skip if you have one).
2. Top-right "+" → New repository → name it `builty-sender` → Private → Create.
3. On the new repo page click "uploading an existing file".
4. Unzip BuiltySender.zip on the computer, open the BuiltySender folder,
   select EVERYTHING inside it (including the `.github` folder; on Mac press
   Cmd+Shift+. to show hidden folders) and drag it into the page.
   Click "Commit changes".
5. Open the "Actions" tab. A "Build APK" run starts by itself (if it asks,
   click "I understand my workflows, go ahead and enable them", then
   "Build APK" → "Run workflow"). Wait ~5 minutes for the green tick.
6. Click the finished run → under "Artifacts" download `BuiltySender-apk`.
   Unzip it to get `app-debug.apk`.
7. Send `app-debug.apk` to your phone (WhatsApp it to yourself or use Drive),
   tap it, allow "Install unknown apps" for that app, then Install.

## Or with Android Studio
Open the BuiltySender folder in Android Studio → Build → Build APK(s).

## Notes
- Android 10 or newer.
- Reading works offline (Google ML Kit, on the phone).
- Saved builties live inside the app on this phone. Uninstalling the app
  deletes them.
- In the app, open "My shop numbers" on the Upload tab and add your own
  numbers so they are never picked as the receiver's.
